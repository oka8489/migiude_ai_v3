from .corins_parser import parse_corins_pdf

__all__ = ["parse_corins_pdf"]
